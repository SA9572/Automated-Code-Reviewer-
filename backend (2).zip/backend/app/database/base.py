from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Base class for all database ORM models."""
