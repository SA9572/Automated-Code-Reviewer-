
import asyncio
import logging
from collections.abc import Sequence

from app.agents.base_agent import BaseAgent
from app.agents.fix_suggestion_agent import FixSuggestionAgent
from app.orchestration.agent_framework_workflow import AgentFrameworkWorkflow
from app.orchestration.parallel_orchestrator import ParallelOrchestrator
from app.orchestration.reviewer_manager import ReviewerManager
from app.schemas.review import Review, ReviewStatus
from app.state.change_state import ChangeState
from app.state.state_manager import StateManager

logger = logging.getLogger(__name__)


class ReviewPipeline:
    """
    Coordinates the complete automated code review workflow.

    Workflow:
    1. Create review state.
    2. Execute specialist agents concurrently using Microsoft Agent Framework.
    3. Persist agent results.
    4. Consolidate findings through ReviewerManager.
    5. Generate fix suggestions for consolidated findings.
    6. Persist fix suggestions.
    7. Return the final review.

    Fix-suggestion generation is non-critical. If it fails, the completed
    code review is still returned successfully.
    """

    def __init__(
        self,
        state_manager: StateManager | None = None,
        agents: Sequence[BaseAgent] | None = None,
        max_concurrency: int = 4,
        fix_suggestion_agent: FixSuggestionAgent | None = None,
    ):
        # Track ownership before constructing the agents.
        self._owns_agents = agents is None
        self._owns_fix_suggestion_agent = fix_suggestion_agent is None
        self._closed = False
        self._closed_services: set[int] = set()

        self.state_manager = state_manager or StateManager()

        # Initialize the existing parallel orchestrator.
        self.orchestrator = ParallelOrchestrator(
            agents=agents,
            state_manager=self.state_manager,
            max_concurrency=max_concurrency,
        )

        # Initialize the Microsoft Agent Framework workflow.
        self.framework_workflow = AgentFrameworkWorkflow(
            self.orchestrator
        )

        self.reviewer_manager = ReviewerManager(
            state_manager=self.state_manager
        )

        self.fix_suggestion_agent = (
            fix_suggestion_agent
            if fix_suggestion_agent is not None
            else FixSuggestionAgent()
        )

    async def close(self) -> None:
        """Close owned LLM services safely and retry failed closures."""

        if self._closed:
            return

        services = {}

        # Collect services from internally created specialist agents.
        if self._owns_agents:
            for agent in self.orchestrator.agents:
                service = getattr(agent, "llm_service", None)

                if service is not None:
                    services[id(service)] = service

        # Collect the internally created Fix Suggestion Agent service.
        if self._owns_fix_suggestion_agent:
            service = getattr(
                self.fix_suggestion_agent,
                "llm_service",
                None,
            )

            if service is not None:
                services[id(service)] = service

        errors = []

        # Close each unique owned service.
        for service_id, service in services.items():

            # Skip services that were already closed successfully.
            if service_id in self._closed_services:
                continue

            close = getattr(service, "close", None)

            if not callable(close):
                self._closed_services.add(service_id)
                continue

            try:
                await close()

                # Record only successful closures.
                self._closed_services.add(service_id)

            except Exception as exc:
                logger.exception(
                    "Failed to close an owned LLM service: %s",
                    type(exc).__name__,
                )
                errors.append(exc)

        # Keep the pipeline retryable if any service failed.
        if errors:
            raise RuntimeError(
                f"Failed to close {len(errors)} owned LLM service(s)."
            ) from errors[0]

        # Mark the pipeline closed only after all services succeed.
        self._closed = True

    async def run(
        self,
        repository: str,
        base_commit: str,
        head_commit: str,
        diff_content: str,
        changed_files: list[str] | None = None,
        pull_request_number: int | None = None,
        test_diff: str | None = None,
        test_files: list[str] | None = None,
    ) -> Review:
        """
        Run the complete review pipeline.

        Returns:
            Final consolidated Review object.

        Note:
            Fix suggestions are persisted separately and do not change
            the Review response schema.
        """

        if not isinstance(diff_content, str):
            raise ValueError("diff_content must be a string")

        if not isinstance(repository, str) or not repository.strip():
            raise ValueError("repository must be a non-empty string")

        if not isinstance(base_commit, str) or not base_commit.strip():
            raise ValueError("base_commit must be a non-empty string")

        if not isinstance(head_commit, str) or not head_commit.strip():
            raise ValueError("head_commit must be a non-empty string")

        changed_files = changed_files or []
        test_files = test_files or []

        # Step 1: Create initial review state.
        state = ChangeState(
            repository=repository,
            pull_request_number=pull_request_number,
            base_commit=base_commit,
            head_commit=head_commit,
            changed_files=changed_files,
            diff_content=diff_content,
        )

        await self.state_manager.create_state(state)

        review_id = state.review_id

        logger.info(
            "Starting review pipeline: review_id=%s repository=%s",
            review_id,
            repository,
        )

        # Prepare shared context for specialist agents.
        context = {
            "review_id": review_id,
            "repository": repository,
            "pull_request_number": pull_request_number,
            "base_commit": base_commit,
            "head_commit": head_commit,
            "changed_files": changed_files,
            "diff_content": diff_content,
            "test_diff": test_diff,
            "test_files": test_files,
        }

        try:
            # Step 2 and 3:
            # Execute specialist agents through the Microsoft Agent
            # Framework workflow and persist their results.
            await self.framework_workflow.run(
                context=context,
                review_id=review_id,
            )

            # Step 4: Consolidate and persist the final review.
            final_review = await self.reviewer_manager.finalize(review_id)

            logger.info(
                "Review consolidation completed: review_id=%s findings=%d",
                review_id,
                len(final_review.findings),
            )

            # Step 5: Generate and persist fix suggestions.
            # This is deliberately non-critical: a suggestion failure
            # must not invalidate an otherwise successful code review.
            if final_review.findings and diff_content.strip():
                try:
                    suggestions = (
                        await self.fix_suggestion_agent.generate_suggestions(
                            review_id=review_id,
                            findings=final_review.findings,
                            diff_content=diff_content,
                        )
                    )

                    if suggestions:
                        await self.state_manager.save_fix_suggestions(
                            review_id=review_id,
                            suggestions=suggestions,
                        )

                    logger.info(
                        "Fix suggestion generation completed: "
                        "review_id=%s suggestions=%d",
                        review_id,
                        len(suggestions),
                    )

                except Exception:
                    logger.exception(
                        "Fix suggestion generation or persistence failed. "
                        "The completed review will still be returned: "
                        "review_id=%s",
                        review_id,
                    )
            else:
                logger.info(
                    "Skipping fix suggestions because there are no findings "
                    "or the diff is empty: review_id=%s",
                    review_id,
                )

            logger.info(
                "Review pipeline completed: review_id=%s status=%s "
                "findings=%d recommendation=%s",
                review_id,
                final_review.status.value,
                len(final_review.findings),
                final_review.recommendation.value,
            )

            # Step 6: Return the final review.
            return final_review

        except asyncio.CancelledError:
            logger.warning(
                "Review pipeline cancelled: review_id=%s",
                review_id,
            )

            await self.state_manager.update_status(
                review_id,
                ReviewStatus.FAILED,
            )

            raise

        except Exception:
            logger.exception(
                "Review pipeline failed: review_id=%s",
                review_id,
            )

            await self.state_manager.update_status(
                review_id,
                ReviewStatus.FAILED,
            )

            raise
