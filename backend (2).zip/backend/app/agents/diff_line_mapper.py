"""Validate LLM-reported finding locations against unified Git diffs."""

from __future__ import annotations

import re
from collections.abc import Iterable
from pathlib import PurePosixPath

_HUNK_HEADER = re.compile(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@")


def _normalize_path(path: str) -> str:
    """Normalize Git/Python path separators for reliable comparisons."""
    normalized = path.strip().replace("\\", "/")

    if normalized.startswith("./"):
        normalized = normalized[2:]

    if normalized.startswith(("a/", "b/")):
        normalized = normalized[2:]

    return str(PurePosixPath(normalized))


def _parse_header_path(line: str) -> str | None:
    """Extract the new-side path from a unified diff +++ header."""
    value = line[4:].split("\t", maxsplit=1)[0].strip()

    if value == "/dev/null":
        return None

    # Git normally prefixes paths with b/. Keep the actual new-side path.
    if value.startswith("b/"):
        value = value[2:]

    # Quoted paths are uncommon in generated diffs. Avoid guessing if the
    # quoting cannot be interpreted safely.
    if value.startswith('"') and value.endswith('"'):
        value = value[1:-1]
        value = (
            value.replace(r"\"", '"')
            .replace(r"\\", "\\")
            .replace(r"\t", "\t")
            .replace(r"\n", "\n")
        )

    return _normalize_path(value) if value else None


def build_changed_line_map(
    diff_contents: str | Iterable[str],
) -> dict[str, set[int]]:
    """
    Return added line numbers keyed by each file's new-side path.

    Only '+' lines inside a valid unified-diff hunk are considered changed.
    Context lines advance the new-side cursor but are not marked as changed.
    Removed lines do not advance the new-side cursor.
    """
    diffs = [diff_contents] if isinstance(diff_contents, str) else list(diff_contents)

    changed_lines: dict[str, set[int]] = {}

    for diff_text in diffs:
        if not isinstance(diff_text, str) or not diff_text:
            continue

        current_path: str | None = None
        new_line_number: int | None = None

        for line in diff_text.splitlines():
            if line.startswith("+++ "):
                current_path = _parse_header_path(line)
                new_line_number = None
                continue

            hunk_match = _HUNK_HEADER.match(line)
            if hunk_match:
                if current_path is None:
                    new_line_number = None
                    continue

                new_start = int(hunk_match.group(1))
                new_count = hunk_match.group(2)

                # A zero-length new hunk has no addressable new-side lines.
                if new_count is not None and int(new_count) == 0:
                    new_line_number = None
                else:
                    new_line_number = new_start
                continue

            if new_line_number is None or current_path is None:
                continue

            if line.startswith("\\"):
                # Git metadata, e.g. "\ No newline at end of file".
                continue

            if line.startswith("+") and not line.startswith("+++"):
                changed_lines.setdefault(current_path, set()).add(new_line_number)
                new_line_number += 1
            elif line.startswith("-") and not line.startswith("---"):
                # A deletion consumes an old-side line, not a new-side line.
                continue
            elif line.startswith(" "):
                # Context consumes one line on both sides.
                new_line_number += 1

    return changed_lines


def validate_finding_location(
    finding_data: dict,
    diff_contents: str | Iterable[str],
) -> dict:
    """
    Return a copy of finding_data with unsupported line locations cleared.

    A reported range is retained only where it overlaps added lines in the
    matching file. Unsupported or unverifiable locations become None.
    """
    validated = finding_data.copy()

    file_path = validated.get("file_path")
    if not isinstance(file_path, str) or not file_path.strip():
        validated["start_line"] = None
        validated["end_line"] = None
        return validated

    changed_line_map = build_changed_line_map(diff_contents)
    normalized_path = _normalize_path(file_path)
    changed_lines = changed_line_map.get(normalized_path, set())

    start_line = validated.get("start_line")
    end_line = validated.get("end_line")

    # No location was claimed; preserve the unavailable values.
    if start_line is None and end_line is None:
        return validated

    # A partial location is retained only if that exact line is changed.
    if start_line is None:
        if end_line not in changed_lines:
            validated["end_line"] = None
        return validated

    if end_line is None:
        if start_line not in changed_lines:
            validated["start_line"] = None
        return validated

    # Keep only the portion of the reported range that overlaps added lines.
    matching_lines = [
        line_number
        for line_number in changed_lines
        if start_line <= line_number <= end_line
    ]

    if not matching_lines:
        validated["start_line"] = None
        validated["end_line"] = None
        return validated

    validated["start_line"] = min(matching_lines)
    validated["end_line"] = max(matching_lines)

    return validated
