from types import SimpleNamespace

import pytest

from app.orchestration.agent_framework_workflow import (
    AgentFrameworkWorkflow,
    ReviewWorkflowOutput,
)
from app.orchestration.parallel_orchestrator import ParallelOrchestrator
from app.schemas.agent_result import AgentResult, AgentStatus


class FakeAgent:
    def __init__(self, agent_name):
        self.agent_name = agent_name
        self.calls = 0

    async def execute(self, context):
        self.calls += 1
        return AgentResult(
            agent_name=self.agent_name,
            status=AgentStatus.SUCCESS,
            summary=f"{self.agent_name} completed",
            findings=[],
            execution_time_ms=10,
        )


class FakeStateManager:
    def __init__(self):
        self.saved = []

    async def update_agent_result(self, review_id, result):
        self.saved.append((review_id, result))


def build_workflow(agent_names):
    agents = [FakeAgent(name) for name in agent_names]
    state_manager = FakeStateManager()
    orchestrator = ParallelOrchestrator(
        agents=agents,
        state_manager=state_manager,
    )
    workflow = AgentFrameworkWorkflow(orchestrator)
    return workflow, agents, state_manager


@pytest.mark.asyncio
async def test_single_specialist_workflow_executes_and_persists():
    workflow, agents, state_manager = build_workflow(["DiffAgent"])

    results = await workflow.run(
        {"diff_content": "sample diff"},
        "review-single",
    )

    assert set(results) == {"DiffAgent"}
    assert agents[0].calls == 1
    assert len(state_manager.saved) == 1
    assert state_manager.saved[0][0] == "review-single"


@pytest.mark.asyncio
async def test_multiple_specialists_execute_and_persist():
    names = [
        "DiffAgent",
        "SecurityAgent",
        "StyleAgent",
        "TestCoverageAgent",
    ]
    workflow, agents, state_manager = build_workflow(names)

    results = await workflow.run(
        {"diff_content": "sample diff"},
        "review-multiple",
    )

    assert set(results) == set(names)
    assert all(agent.calls == 1 for agent in agents)
    assert len(state_manager.saved) == len(names)
    assert {
        review_id for review_id, _ in state_manager.saved
    } == {"review-multiple"}


@pytest.mark.asyncio
async def test_workflow_rejects_non_dictionary_context():
    workflow, _, _ = build_workflow(["DiffAgent"])

    with pytest.raises(ValueError, match="context"):
        await workflow.run("not a dictionary", "review-invalid")


@pytest.mark.asyncio
async def test_workflow_rejects_empty_review_id():
    workflow, _, _ = build_workflow(["DiffAgent"])

    with pytest.raises(ValueError, match="review_id"):
        await workflow.run({}, "  ")


def test_workflow_rejects_missing_or_duplicate_specialist_outputs():
    valid = AgentResult(
        agent_name="DiffAgent",
        status=AgentStatus.SUCCESS,
        summary="Completed",
    )

    with pytest.raises(RuntimeError, match="duplicate"):
        AgentFrameworkWorkflow._validate_output(
            ReviewWorkflowOutput(
                review_id="review-1",
                results=[valid, valid],
            ),
            "review-1",
            {"DiffAgent"},
        )

    with pytest.raises(RuntimeError, match="do not match"):
        AgentFrameworkWorkflow._validate_output(
            ReviewWorkflowOutput(
                review_id="review-1",
                results=[valid],
            ),
            "review-1",
            {"DiffAgent", "SecurityAgent"},
        )


def test_workflow_rejects_unexpected_specialist_output():
    result = AgentResult(
        agent_name="UnexpectedAgent",
        status=AgentStatus.SUCCESS,
        summary="Completed",
    )

    with pytest.raises(RuntimeError, match="do not match"):
        AgentFrameworkWorkflow._validate_output(
            ReviewWorkflowOutput(
                review_id="review-1",
                results=[result],
            ),
            "review-1",
            {"DiffAgent"},
        )


def test_workflow_rejects_wrong_review_id():
    result = AgentResult(
        agent_name="DiffAgent",
        status=AgentStatus.SUCCESS,
        summary="Completed",
    )

    with pytest.raises(RuntimeError, match="review ID mismatch"):
        AgentFrameworkWorkflow._validate_output(
            ReviewWorkflowOutput(
                review_id="wrong-review",
                results=[result],
            ),
            "review-1",
            {"DiffAgent"},
        )


@pytest.mark.asyncio
async def test_workflow_requires_state_manager_for_persistence():
    agent = FakeAgent("DiffAgent")
    orchestrator = ParallelOrchestrator(agents=[agent])
    workflow = AgentFrameworkWorkflow(orchestrator)

    with pytest.raises(RuntimeError, match="StateManager"):
        await workflow.run({}, "review-no-state-manager")