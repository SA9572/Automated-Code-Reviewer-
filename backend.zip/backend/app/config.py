from functools import lru_cache

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    APP_NAME: str = "Automated Code Review Board"

    APP_ENV: str = "development"

    DEBUG: bool = True

    GROQ_API_KEY: SecretStr

    GROQ_MODEL: str

    GROQ_BASE_URL: str = "https://api.groq.com/openai/v1"

    LLM_TIMEOUT_SECONDS: float = Field(
        default=60.0,
        gt=0,
        description="Maximum execution time per agent attempt, in seconds",
    )

    MAX_RETRIES: int = 2

    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", extra="ignore"
    )


@lru_cache
def get_settings() -> Settings:
    return Settings()
