import logging
import re
from typing import ClassVar

from app.schemas.agent_result import AgentStatus
from app.schemas.finding import Finding, Severity
from app.schemas.review import (
    MergeRecommendation,
    Review,
    ReviewStatus,
)
from app.state.state_manager import StateManager

logger = logging.getLogger(__name__)


class ReviewerManager:
    """
    Consolidates specialist agent results into a final review.

    Responsibilities:
    - Collect findings.
    - Deduplicate overlapping findings.
    - Rank findings by severity and confidence.
    - Generate a summary.
    - Determine merge recommendation.
    - Persist the final review.
    """

    SEVERITY_RANK: ClassVar[dict[Severity, int]] = {
        Severity.CRITICAL: 5,
        Severity.HIGH: 4,
        Severity.MEDIUM: 3,
        Severity.LOW: 2,
        Severity.INFO: 1,
    }

    def __init__(self, state_manager: StateManager):
        if state_manager is None:
            raise ValueError("state_manager is required")

        self.state_manager = state_manager

    async def finalize(self, review_id: str) -> Review:
        """Generate and persist the final consolidated review."""

        state = await self.state_manager.get_state(review_id)

        agent_results = state.agent_results

        if not agent_results:
            raise ValueError("Cannot finalize a review without agent results")

        successful_agents = [
            result
            for result in agent_results.values()
            if result.status == AgentStatus.SUCCESS
        ]

        unsuccessful_agents = [
            result
            for result in agent_results.values()
            if result.status != AgentStatus.SUCCESS
        ]

        # Collect findings from successful agents only.
        all_findings = []

        for result in successful_agents:
            all_findings.extend(result.findings)

        # Remove duplicate findings.
        findings = self.deduplicate_findings(all_findings)

        # Sort findings by severity and confidence.
        findings = self.rank_findings(findings)

        # Determine merge recommendation.
        recommendation = self._get_recommendation(
            findings,
            has_failures=bool(unsuccessful_agents),
        )

        # Generate final review summary.
        summary = self._build_summary(
            findings,
            successful_count=len(successful_agents),
            failed_count=len(unsuccessful_agents),
        )

        # Persist consolidated findings and summary.
        updated_state = await self.state_manager.update_final_review(
            review_id=review_id,
            findings=findings,
            recommendation=recommendation,
            summary=summary,
        )

        # Determine final review status.
        if unsuccessful_agents:
            final_status = ReviewStatus.PARTIAL
        else:
            final_status = ReviewStatus.COMPLETED

        if not successful_agents:
            final_status = ReviewStatus.FAILED

        if final_status != updated_state.status:
            updated_state = await self.state_manager.update_status(
                review_id,
                final_status,
            )

        logger.info(
            "Review %s finalized: %d findings, recommendation=%s",
            review_id,
            len(findings),
            recommendation.value,
        )

        return Review(
            review_id=updated_state.review_id,
            repository=updated_state.repository,
            pull_request_number=updated_state.pull_request_number,
            base_commit=updated_state.base_commit,
            head_commit=updated_state.head_commit,
            status=updated_state.status,
            agent_results=updated_state.agent_results,
            findings=updated_state.final_findings,
            summary=updated_state.change_summary,
            recommendation=updated_state.recommendation,
            created_at=updated_state.created_at,
            completed_at=updated_state.completed_at,
        )

    @classmethod
    def rank_findings(
        cls,
        findings: list[Finding],
    ) -> list[Finding]:
        """Sort findings by severity, then confidence."""

        return sorted(
            findings,
            key=lambda finding: (
                cls.SEVERITY_RANK[finding.severity],
                finding.confidence,
            ),
            reverse=True,
        )

    @staticmethod
    def _normalize_text(value: str) -> str:
        return re.sub(
            r"\s+",
            " ",
            value.strip().casefold(),
        )

    @classmethod
    def deduplicate_findings(
        cls,
        findings: list[Finding],
    ) -> list[Finding]:
        """
        Deduplicate findings using normalized file path and evidence.

        Findings without evidence use their normalized title.
        Preserve the highest severity and confidence.
        """

        unique = {}

        severity_rank = cls.SEVERITY_RANK

        for finding in findings:
            file_path = cls._normalize_text(finding.file_path.replace("\\", "/"))

            evidence = cls._normalize_text(finding.evidence)

            identity = (
                file_path,
                evidence or cls._normalize_text(finding.title),
            )

            existing = unique.get(identity)

            if existing is None:
                unique[identity] = finding.model_copy(deep=True)
                continue

            existing_rank = severity_rank[existing.severity]
            new_rank = severity_rank[finding.severity]

            if new_rank > existing_rank or (
                new_rank == existing_rank and finding.confidence > existing.confidence
            ):
                unique[identity] = finding.model_copy(deep=True)

        return list(unique.values())

    @staticmethod
    def _get_recommendation(
        findings: list[Finding],
        has_failures: bool = False,
    ) -> MergeRecommendation:
        """
        Determine the merge recommendation.

        CRITICAL/HIGH findings always request changes.
        Failed agents prevent automatic approval.
        MEDIUM findings require manual review.
        """

        # Serious findings take priority over agent failures.
        for finding in findings:
            if finding.severity in {
                Severity.CRITICAL,
                Severity.HIGH,
            }:
                return MergeRecommendation.REQUEST_CHANGES

        # Incomplete analysis must never result in automatic approval.
        if has_failures:
            return MergeRecommendation.REVIEW_REQUIRED

        # Medium-severity findings require manual review.
        for finding in findings:
            if finding.severity == Severity.MEDIUM:
                return MergeRecommendation.REVIEW_REQUIRED

        # No blocking or review-required findings.
        return MergeRecommendation.APPROVE

    @staticmethod
    def _build_summary(
        findings: list[Finding],
        successful_count: int,
        failed_count: int,
    ) -> str:

        counts = {severity.value: 0 for severity in Severity}

        for finding in findings:
            counts[finding.severity.value] += 1

        summary = (
            f"Review completed with {len(findings)} unique findings. "
            f"Agents successful: {successful_count}; "
            f"agents unsuccessful: {failed_count}. "
            f"Critical: {counts['CRITICAL']}, "
            f"High: {counts['HIGH']}, "
            f"Medium: {counts['MEDIUM']}, "
            f"Low: {counts['LOW']}, "
            f"Info: {counts['INFO']}."
        )

        return summary
