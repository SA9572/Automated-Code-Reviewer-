import asyncio
import logging
from collections.abc import Sequence

from app.agents.base_agent import BaseAgent
from app.orchestration.parallel_orchestrator import ParallelOrchestrator
from app.orchestration.reviewer_manager import ReviewerManager
from app.schemas.review import Review, ReviewStatus
from app.state.change_state import ChangeState
from app.state.state_manager import StateManager

logger = logging.getLogger(__name__)


class ReviewPipeline:
    """
    Coordinates the complete automated code review workflow.

    Workflow:
    1. Create review state.
    2. Execute specialist agents concurrently.
    3. Persist agent results.
    4. Consolidate findings.
    5. Generate and return the final review.
    """

    def __init__(
        self,
        state_manager: StateManager | None = None,
        agents: Sequence[BaseAgent] | None = None,
        max_concurrency: int = 4,
    ):
        self.state_manager = state_manager or StateManager()

        self.orchestrator = ParallelOrchestrator(
            agents=agents,
            state_manager=self.state_manager,
            max_concurrency=max_concurrency,
        )

        self.reviewer_manager = ReviewerManager(state_manager=self.state_manager)

    async def run(
        self,
        repository: str,
        base_commit: str,
        head_commit: str,
        diff_content: str,
        changed_files: list[str] | None = None,
        pull_request_number: int | None = None,
        test_diff: str | None = None,
        test_files: list[str] | None = None,
    ) -> Review:
        """
        Run the complete review pipeline.

        Returns:
            Final consolidated Review object.
        """

        if not isinstance(diff_content, str):
            raise ValueError("diff_content must be a string")

        if not isinstance(repository, str) or not repository.strip():
            raise ValueError("repository must be a non-empty string")

        if not isinstance(base_commit, str) or not base_commit.strip():
            raise ValueError("base_commit must be a non-empty string")

        if not isinstance(head_commit, str) or not head_commit.strip():
            raise ValueError("head_commit must be a non-empty string")

        changed_files = changed_files or []
        test_files = test_files or []

        # Step 1: Create initial review state.
        state = ChangeState(
            repository=repository,
            pull_request_number=pull_request_number,
            base_commit=base_commit,
            head_commit=head_commit,
            changed_files=changed_files,
            diff_content=diff_content,
        )

        await self.state_manager.create_state(state)

        review_id = state.review_id

        logger.info(
            "Starting review pipeline: review_id=%s repository=%s",
            review_id,
            repository,
        )

        # Prepare shared context for specialist agents.
        context = {
            "review_id": review_id,
            "repository": repository,
            "pull_request_number": pull_request_number,
            "base_commit": base_commit,
            "head_commit": head_commit,
            "changed_files": changed_files,
            "diff_content": diff_content,
            "test_diff": test_diff,
            "test_files": test_files,
        }

        try:
            # Step 2: Execute all specialist agents concurrently.
            # Step 3: Orchestrator persists each agent result.
            await self.orchestrator.run(
                context=context,
                review_id=review_id,
            )

            # Step 4: Consolidate and persist final review.
            final_review = await self.reviewer_manager.finalize(review_id)

            logger.info(
                "Review pipeline completed: review_id=%s status=%s "
                "findings=%d recommendation=%s",
                review_id,
                final_review.status.value,
                len(final_review.findings),
                final_review.recommendation.value,
            )

            # Step 5: Return final review.
            return final_review

        except asyncio.CancelledError:
            logger.warning(
                "Review pipeline cancelled: review_id=%s",
                review_id,
            )
            await self.state_manager.update_status(
                review_id,
                ReviewStatus.FAILED,
            )
            raise

        except Exception:
            logger.exception(
                "Review pipeline failed: review_id=%s",
                review_id,
            )

            await self.state_manager.update_status(
                review_id,
                ReviewStatus.FAILED,
            )

            raise
