from functools import lru_cache

from app.database.connection import AsyncSessionLocal
from app.orchestration.review_pipeline import ReviewPipeline
from app.state.state_manager import StateManager


@lru_cache
def get_review_pipeline() -> ReviewPipeline:
    """Return a shared pipeline backed by persistent SQLite storage."""

    state_manager = StateManager(
        session_factory=AsyncSessionLocal,
    )

    return ReviewPipeline(state_manager=state_manager)
