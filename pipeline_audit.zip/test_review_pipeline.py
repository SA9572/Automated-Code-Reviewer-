import pytest

from app.agents.base_agent import AgentOutput, BaseAgent
from app.orchestration.review_pipeline import ReviewPipeline
from app.schemas.agent_result import AgentStatus
from app.schemas.finding import Finding, Severity
from app.schemas.review import MergeRecommendation, ReviewStatus
from app.state.state_manager import StateManager


class MockAgent(BaseAgent):
    def __init__(
        self,
        agent_name,
        findings=None,
        should_fail=False,
    ):
        self.agent_name = agent_name
        self.findings = findings or []
        self.should_fail = should_fail

    async def execute(self, context):
        if self.should_fail:
            from app.schemas.agent_result import AgentResult

            return AgentResult(
                agent_name=self.agent_name,
                status=AgentStatus.FAILED,
                summary="Mock agent failure",
                findings=[],
                execution_time_ms=10,
                error="Simulated failure",
            )

        from app.schemas.agent_result import AgentResult

        return AgentResult(
            agent_name=self.agent_name,
            status=AgentStatus.SUCCESS,
            summary="Mock analysis completed",
            findings=self.findings,
            execution_time_ms=10,
        )

    async def _analyze(self, context):
        return AgentOutput(
            summary="Mock analysis completed",
            findings=self.findings,
        )


def make_finding(severity=Severity.LOW):
    return Finding(
        agent_name="DiffAgent",
        title="Potential code issue",
        description="A potential issue was detected.",
        severity=severity,
        confidence=0.95,
        file_path="app/main.py",
        evidence="example problematic code",
        recommendation="Review and fix the code.",
    )


@pytest.mark.asyncio
async def test_pipeline_completes_successfully():
    state_manager = StateManager()

    agents = [
        MockAgent("DiffAgent", [make_finding(Severity.HIGH)]),
        MockAgent("StyleAgent"),
        MockAgent("SecurityAgent"),
        MockAgent("TestCoverageAgent"),
    ]

    pipeline = ReviewPipeline(
        state_manager=state_manager,
        agents=agents,
    )

    review = await pipeline.run(
        repository="test/repository",
        base_commit="abc123",
        head_commit="def456",
        diff_content="--- a/app/main.py\n+++ b/app/main.py",
        changed_files=["app/main.py"],
    )

    assert review.status == ReviewStatus.COMPLETED
    assert review.recommendation == MergeRecommendation.REQUEST_CHANGES
    assert len(review.agent_results) == 4
    assert len(review.findings) == 1


@pytest.mark.asyncio
async def test_pipeline_persists_agent_results():
    state_manager = StateManager()

    pipeline = ReviewPipeline(
        state_manager=state_manager,
        agents=[
            MockAgent("DiffAgent"),
            MockAgent("StyleAgent"),
        ],
    )

    review = await pipeline.run(
        repository="test/repository",
        base_commit="abc123",
        head_commit="def456",
        diff_content="sample diff",
    )

    state = await state_manager.get_state(review.review_id)

    assert len(state.agent_results) == 2
    assert state.status == ReviewStatus.COMPLETED


@pytest.mark.asyncio
async def test_pipeline_handles_partial_agent_failure():
    state_manager = StateManager()

    pipeline = ReviewPipeline(
        state_manager=state_manager,
        agents=[
            MockAgent("DiffAgent", [make_finding(Severity.LOW)]),
            MockAgent("SecurityAgent", should_fail=True),
        ],
    )

    review = await pipeline.run(
        repository="test/repository",
        base_commit="abc123",
        head_commit="def456",
        diff_content="sample diff",
    )

    assert review.status == ReviewStatus.PARTIAL
    assert review.recommendation == MergeRecommendation.REVIEW_REQUIRED
    assert len(review.agent_results) == 2


@pytest.mark.asyncio
async def test_pipeline_all_agents_fail():
    state_manager = StateManager()

    pipeline = ReviewPipeline(
        state_manager=state_manager,
        agents=[
            MockAgent("DiffAgent", should_fail=True),
            MockAgent("SecurityAgent", should_fail=True),
        ],
    )

    review = await pipeline.run(
        repository="test/repository",
        base_commit="abc123",
        head_commit="def456",
        diff_content="sample diff",
    )

    assert review.status == ReviewStatus.FAILED
    assert review.recommendation == MergeRecommendation.REVIEW_REQUIRED
    assert review.findings == []


@pytest.mark.asyncio
async def test_pipeline_rejects_empty_repository():
    pipeline = ReviewPipeline(
        agents=[MockAgent("DiffAgent")],
    )

    with pytest.raises(ValueError, match="repository"):
        await pipeline.run(
            repository="",
            base_commit="abc123",
            head_commit="def456",
            diff_content="sample diff",
        )


@pytest.mark.asyncio
async def test_pipeline_rejects_invalid_diff_type():
    pipeline = ReviewPipeline(
        agents=[MockAgent("DiffAgent")],
    )

    with pytest.raises(ValueError, match="diff_content"):
        await pipeline.run(
            repository="test/repository",
            base_commit="abc123",
            head_commit="def456",
            diff_content=None,
        )
